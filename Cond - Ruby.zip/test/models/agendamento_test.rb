require 'test_helper'

class AgendamentoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
