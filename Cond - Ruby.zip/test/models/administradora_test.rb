require 'test_helper'

class AdministradoraTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
