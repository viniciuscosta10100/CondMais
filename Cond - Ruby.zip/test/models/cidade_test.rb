require 'test_helper'

class CidadeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
