require 'test_helper'

class CondominioTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
