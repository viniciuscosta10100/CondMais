require 'test_helper'

class AmbienteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
