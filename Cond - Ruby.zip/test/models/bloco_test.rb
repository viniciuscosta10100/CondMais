require 'test_helper'

class BlocoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
