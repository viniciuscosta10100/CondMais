require 'test_helper'

class ComentarioReinvidicacaoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
