require 'test_helper'

class ReinvidicacoesControllerTest < ActionController::TestCase
  setup do
    @reinvidicacao = reinvidicacoes(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:reinvidicacoes)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create reinvidicacao" do
    assert_difference('Reinvidicacao.count') do
      post :create, reinvidicacao: { foto: @reinvidicacao.foto, mensagem: @reinvidicacao.mensagem, status: @reinvidicacao.status, user_id: @reinvidicacao.user_id }
    end

    assert_redirected_to reinvidicacao_path(assigns(:reinvidicacao))
  end

  test "should show reinvidicacao" do
    get :show, id: @reinvidicacao
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @reinvidicacao
    assert_response :success
  end

  test "should update reinvidicacao" do
    patch :update, id: @reinvidicacao, reinvidicacao: { foto: @reinvidicacao.foto, mensagem: @reinvidicacao.mensagem, status: @reinvidicacao.status, user_id: @reinvidicacao.user_id }
    assert_redirected_to reinvidicacao_path(assigns(:reinvidicacao))
  end

  test "should destroy reinvidicacao" do
    assert_difference('Reinvidicacao.count', -1) do
      delete :destroy, id: @reinvidicacao
    end

    assert_redirected_to reinvidicacoes_path
  end
end
