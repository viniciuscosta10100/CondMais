require 'test_helper'

class ComentarioReinvidicacoesControllerTest < ActionController::TestCase
  setup do
    @comentario_reinvidicacao = comentario_reinvidicacoes(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:comentario_reinvidicacoes)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create comentario_reinvidicacao" do
    assert_difference('ComentarioReinvidicacao.count') do
      post :create, comentario_reinvidicacao: { mensagem: @comentario_reinvidicacao.mensagem, reinvidicacao_id: @comentario_reinvidicacao.reinvidicacao_id, user_id: @comentario_reinvidicacao.user_id }
    end

    assert_redirected_to comentario_reinvidicacao_path(assigns(:comentario_reinvidicacao))
  end

  test "should show comentario_reinvidicacao" do
    get :show, id: @comentario_reinvidicacao
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @comentario_reinvidicacao
    assert_response :success
  end

  test "should update comentario_reinvidicacao" do
    patch :update, id: @comentario_reinvidicacao, comentario_reinvidicacao: { mensagem: @comentario_reinvidicacao.mensagem, reinvidicacao_id: @comentario_reinvidicacao.reinvidicacao_id, user_id: @comentario_reinvidicacao.user_id }
    assert_redirected_to comentario_reinvidicacao_path(assigns(:comentario_reinvidicacao))
  end

  test "should destroy comentario_reinvidicacao" do
    assert_difference('ComentarioReinvidicacao.count', -1) do
      delete :destroy, id: @comentario_reinvidicacao
    end

    assert_redirected_to comentario_reinvidicacoes_path
  end
end
