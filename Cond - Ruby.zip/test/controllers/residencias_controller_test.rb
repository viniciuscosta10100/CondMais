require 'test_helper'

class ResidenciasControllerTest < ActionController::TestCase
  setup do
    @residencia = residencias(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:residencias)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create residencia" do
    assert_difference('Residencia.count') do
      post :create, residencia: { administradora_id: @residencia.administradora_id, ativo: @residencia.ativo, bloco_id: @residencia.bloco_id, condominio_id: @residencia.condominio_id, numero: @residencia.numero }
    end

    assert_redirected_to residencia_path(assigns(:residencia))
  end

  test "should show residencia" do
    get :show, id: @residencia
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @residencia
    assert_response :success
  end

  test "should update residencia" do
    patch :update, id: @residencia, residencia: { administradora_id: @residencia.administradora_id, ativo: @residencia.ativo, bloco_id: @residencia.bloco_id, condominio_id: @residencia.condominio_id, numero: @residencia.numero }
    assert_redirected_to residencia_path(assigns(:residencia))
  end

  test "should destroy residencia" do
    assert_difference('Residencia.count', -1) do
      delete :destroy, id: @residencia
    end

    assert_redirected_to residencias_path
  end
end
