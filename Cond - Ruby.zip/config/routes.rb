Rails.application.routes.draw do
  resources :comentario_reinvidicacoes
  resources :reinvidicacoes
  resources :agendamentos
  resources :avisos
  resources :ambientes
  resources :residencias
  resources :blocos
  resources :condominios
  resources :administradoras
  devise_for :users, :controllers => { :registrations => "registrations",:sessions => "sessions"  }

  devise_scope :user do
    authenticated :user do
      root 'route#root', as: :authenticated_root

    end

    unauthenticated do
      root 'devise/sessions#new', as: :unauthenticated_root
    end
  end
  get 'mensagens/:id' => 'mensagens#show'
  get 'mensagens' => 'mensagens#index'
  get 'getMensagens' => 'mensagens#getMensagens'
  get 'resend_alert' => 'avisos#resend'
  post 'sendmsg' => 'mensagens#sendMsg'
  post 'sendAviso' => 'avisos#sendAviso'
  post 'resend' => 'avisos#resend'
  post 'desativarAviso' => 'avisos#desativar'
  post 'logout' => 'users#logout'
  get 'agenda' => 'agenda#index'
  post 'novomembro' => 'users#cadastroMembro'
  post 'verify_cpf' => 'users#verifyCadastro'
  post 'mensagens' => 'mensagens#save'
  get 'usuarios' => 'users#usuarios'
  get 'moradores' => 'users#moradores'
  get 'administradores' => 'users#administradores'
  get 'sindicos' => 'users#sindicos'
  get 'get_cidades' => 'condominios#get_cidades'
  get 'get_blocos' => 'residencias#get_blocos'
  post 'alterar_usuario' => 'users#alterar_usuario'
end
