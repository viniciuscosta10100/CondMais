# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20170505121400) do

  create_table "administradoras", force: :cascade do |t|
    t.string   "nome",       limit: 255
    t.string   "cnpj",       limit: 255
    t.string   "ativo",      limit: 255, default: "S", null: false
    t.string   "logo",       limit: 255
    t.datetime "created_at",                           null: false
    t.datetime "updated_at",                           null: false
  end

  create_table "agendamentos", force: :cascade do |t|
    t.integer  "user_id",     limit: 4
    t.date     "data"
    t.time     "hora"
    t.integer  "ambiente_id", limit: 4
    t.datetime "created_at",            null: false
    t.datetime "updated_at",            null: false
  end

  create_table "alternativa_enquetes", force: :cascade do |t|
    t.string   "titulo",     limit: 255
    t.integer  "enquete_id", limit: 4
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
  end

  create_table "ambientes", force: :cascade do |t|
    t.string   "nome",              limit: 255
    t.string   "ativo",             limit: 255, default: "S"
    t.integer  "administradora_id", limit: 4
    t.integer  "condominio_id",     limit: 4
    t.datetime "created_at",                                  null: false
    t.datetime "updated_at",                                  null: false
  end

  create_table "avisos", force: :cascade do |t|
    t.string   "mensagem",          limit: 255
    t.integer  "tipo",              limit: 4
    t.integer  "condominio_id",     limit: 4
    t.datetime "created_at",                                  null: false
    t.datetime "updated_at",                                  null: false
    t.string   "ativo",             limit: 255, default: "S", null: false
    t.string   "remetente",         limit: 255
    t.integer  "user_id",           limit: 4
    t.integer  "administradora_id", limit: 4
  end

  create_table "blocos", force: :cascade do |t|
    t.string   "nome",              limit: 255
    t.integer  "condominio_id",     limit: 4
    t.integer  "administradora_id", limit: 4
    t.string   "ativo",             limit: 255, default: "S", null: false
    t.datetime "created_at",                                  null: false
    t.datetime "updated_at",                                  null: false
  end

  create_table "cidades", force: :cascade do |t|
    t.string   "cod",        limit: 255
    t.string   "nome",       limit: 255
    t.integer  "estado_id",  limit: 4
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "comentario_reinvidicacoes", force: :cascade do |t|
    t.integer  "reinvidicacao_id", limit: 4
    t.text     "mensagem",         limit: 65535
    t.integer  "user_id",          limit: 4
    t.datetime "created_at",                     null: false
    t.datetime "updated_at",                     null: false
    t.boolean  "concluido",        limit: 1
  end

  create_table "condominios", force: :cascade do |t|
    t.string   "nome",              limit: 255
    t.integer  "cidade_id",         limit: 4
    t.integer  "estado_id",         limit: 4
    t.string   "cep",               limit: 255
    t.string   "endereco",          limit: 255
    t.string   "foto",              limit: 255
    t.string   "latitude",          limit: 255
    t.string   "longitude",         limit: 255
    t.integer  "administradora_id", limit: 4
    t.string   "ativo",             limit: 255, default: "S", null: false
    t.datetime "created_at",                                  null: false
    t.datetime "updated_at",                                  null: false
  end

  create_table "enquetes", force: :cascade do |t|
    t.string   "titulo",        limit: 255
    t.string   "ativo",         limit: 255, default: "S", null: false
    t.integer  "condominio_id", limit: 4
    t.datetime "created_at",                              null: false
    t.datetime "updated_at",                              null: false
  end

  create_table "estados", force: :cascade do |t|
    t.string   "nome",       limit: 255
    t.string   "uf",         limit: 255
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "membros", force: :cascade do |t|
    t.string   "cpf",        limit: 255
    t.integer  "user_id",    limit: 4
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
  end

  create_table "mensagens", force: :cascade do |t|
    t.string   "texto",           limit: 255
    t.integer  "condominio_id",   limit: 4
    t.datetime "created_at",                  null: false
    t.datetime "updated_at",                  null: false
    t.integer  "remetente_id",    limit: 4
    t.integer  "destinatario_id", limit: 4
  end

  create_table "modeis", force: :cascade do |t|
    t.string   "cpf",        limit: 255
    t.integer  "user_id",    limit: 4
    t.datetime "created_at",             null: false
    t.datetime "updated_at",             null: false
  end

  create_table "reinvidicacoes", force: :cascade do |t|
    t.binary   "foto",              limit: 4294967295
    t.text     "mensagem",          limit: 65535
    t.integer  "user_id",           limit: 4
    t.string   "status",            limit: 255
    t.datetime "created_at",                           null: false
    t.datetime "updated_at",                           null: false
    t.integer  "administradora_id", limit: 4
    t.integer  "condominio_id",     limit: 4
  end

  create_table "residencias", force: :cascade do |t|
    t.string   "numero",            limit: 255
    t.integer  "administradora_id", limit: 4
    t.integer  "condominio_id",     limit: 4
    t.integer  "bloco_id",          limit: 4
    t.string   "ativo",             limit: 255, default: "S", null: false
    t.datetime "created_at",                                  null: false
    t.datetime "updated_at",                                  null: false
    t.string   "cpf_titular",       limit: 255
  end

  create_table "users", force: :cascade do |t|
    t.string   "email",                  limit: 255,        default: "",  null: false
    t.string   "encrypted_password",     limit: 255,        default: "",  null: false
    t.string   "nome",                   limit: 255,        default: "",  null: false
    t.string   "tipo",                   limit: 255,        default: "",  null: false
    t.string   "ativo",                  limit: 255,        default: "S", null: false
    t.string   "telefone",               limit: 255,        default: "S", null: false
    t.string   "sexo",                   limit: 255,        default: "S", null: false
    t.integer  "condominio_id",          limit: 4
    t.string   "reset_password_token",   limit: 255
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",          limit: 4,          default: 0,   null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip",     limit: 255
    t.string   "last_sign_in_ip",        limit: 255
    t.datetime "created_at",                                              null: false
    t.datetime "updated_at",                                              null: false
    t.integer  "administradora_id",      limit: 4
    t.string   "gcm",                    limit: 255
    t.string   "ios_token",              limit: 255
    t.integer  "residencia_id",          limit: 4
    t.text     "foto",                   limit: 4294967295
    t.string   "cpf",                    limit: 255
  end

  add_index "users", ["email"], name: "index_users_on_email", unique: true, using: :btree
  add_index "users", ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true, using: :btree

end
