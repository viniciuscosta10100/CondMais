class CreateAgendamentos < ActiveRecord::Migration
  def change
    create_table :agendamentos do |t|
      t.integer :user_id
      t.date :data
      t.time :hora
      t.integer :ambiente_id

      t.timestamps null: false
    end
  end
end
