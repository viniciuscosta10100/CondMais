class CreateMensagens < ActiveRecord::Migration
  def change
    create_table :mensagens do |t|
      t.string :texto
      t.integer :user_id
      t.integer :condominio_id

      t.timestamps null: false
    end
  end
end
