class AddAtivoToAvisos < ActiveRecord::Migration
  def change
    add_column :avisos, :ativo, :string, null: false, default: "S"
  end
end
