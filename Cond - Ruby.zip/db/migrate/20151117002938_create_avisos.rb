class CreateAvisos < ActiveRecord::Migration
  def change
    create_table :avisos do |t|
      t.string :mensagem
      t.integer :tipo
      t.integer :condominio_id

      t.timestamps null: false
    end
  end
end
