class AddAdministradoraIdToAvisos < ActiveRecord::Migration
  def change
    add_column :avisos, :administradora_id, :integer
  end
end
