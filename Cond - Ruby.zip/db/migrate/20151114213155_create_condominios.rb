class CreateCondominios < ActiveRecord::Migration
  def change
    create_table :condominios do |t|
      t.string :nome
      t.integer :cidade_id
      t.integer :estado_id
      t.string :cep
      t.string :endereco
      t.string :foto
      t.string :latitude
      t.string :longitude
      t.integer :administradora_id
      t.string :ativo,              null: false, default: "S"

      t.timestamps null: false
    end
  end
end
