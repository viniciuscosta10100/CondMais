class CreateAmbientes < ActiveRecord::Migration
  def change
    create_table :ambientes do |t|
      t.string :nome
      t.string :ativo,              null: false, default: "S"
      t.integer :administradora_id
      t.integer :condominio_id

      t.timestamps null: false
    end
  end
end
