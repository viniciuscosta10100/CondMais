class CreateResidencias < ActiveRecord::Migration
  def change
    create_table :residencias do |t|
      t.string :numero
      t.integer :administradora_id
      t.integer :condominio_id
      t.integer :bloco_id
      t.string :ativo,              null: false, default: "S"

      t.timestamps null: false
    end
  end
end
