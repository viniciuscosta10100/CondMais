class CreateBlocos < ActiveRecord::Migration
  def change
    create_table :blocos do |t|
      t.string :nome
      t.integer :condominio_id
      t.integer :administradora_id
      t.string :ativo,              null: false, default: "S"

      t.timestamps null: false
    end
  end
end
