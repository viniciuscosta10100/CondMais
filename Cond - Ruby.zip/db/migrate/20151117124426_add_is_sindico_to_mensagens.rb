class AddIsSindicoToMensagens < ActiveRecord::Migration
  def change
    add_column :mensagens, :isSindico, :string, null: false, default: "N"
  end
end
