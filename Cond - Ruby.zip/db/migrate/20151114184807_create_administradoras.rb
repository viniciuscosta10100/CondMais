class CreateAdministradoras < ActiveRecord::Migration
  def change
    create_table :administradoras do |t|
      t.string :nome
      t.string :cnpj
      t.string :ativo,              null: false, default: "S"
      t.string :logo

      t.timestamps null: false
    end
  end
end
