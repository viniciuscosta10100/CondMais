class AddRemetenteToAvisos < ActiveRecord::Migration
  def change
    add_column :avisos, :remetente, :string
    add_column :avisos, :user_id, :integer
  end
end
