class CreateComentarioReinvidicacoes < ActiveRecord::Migration
  def change
    create_table :comentario_reinvidicacoes do |t|
      t.integer :reinvidicacao_id
      t.text :mensagem
      t.integer :user_id

      t.timestamps null: false
    end
  end
end
