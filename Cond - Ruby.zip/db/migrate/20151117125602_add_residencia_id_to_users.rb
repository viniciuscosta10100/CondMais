class AddResidenciaIdToUsers < ActiveRecord::Migration
  def change
    add_column :users, :residencia_id, :integer
  end
end
