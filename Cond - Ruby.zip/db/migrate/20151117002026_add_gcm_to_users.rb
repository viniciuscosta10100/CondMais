class AddGcmToUsers < ActiveRecord::Migration
  def change
    add_column :users, :gcm, :string
    add_column :users, :ios_token, :string
  end
end
