class AddCpfTitularToResidencias < ActiveRecord::Migration
  def change
    add_column :residencias, :cpf_titular, :string
  end
end
