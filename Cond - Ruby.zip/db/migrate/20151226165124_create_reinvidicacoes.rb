class CreateReinvidicacoes < ActiveRecord::Migration
  def change
    create_table :reinvidicacoes do |t|
      t.binary :foto, :limit => 16.megabyte
      t.text :mensagem
      t.integer :user_id
      t.string :status

      t.timestamps null: false
    end
  end
end
