class AddConcluidoToComentarioReinvidicacoes < ActiveRecord::Migration
  def change
    add_column :comentario_reinvidicacoes, :concluido, :boolean
  end
end
