class AddAdministradoraIdToReinvidicacoes < ActiveRecord::Migration
  def change
    add_column :reinvidicacoes, :administradora_id, :integer
    add_column :reinvidicacoes, :condominio_id, :integer
  end
end
