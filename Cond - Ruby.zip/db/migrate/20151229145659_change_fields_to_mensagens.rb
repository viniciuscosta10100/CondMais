class ChangeFieldsToMensagens < ActiveRecord::Migration
  def change
    remove_column :mensagens, :user_id
    remove_column :mensagens, :isSindico
    add_column :mensagens, :remetente_id, :integer
    add_column :mensagens, :destinatario_id, :integer
  end
end
