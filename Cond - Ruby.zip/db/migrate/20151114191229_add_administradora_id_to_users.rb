class AddAdministradoraIdToUsers < ActiveRecord::Migration
  def change
    add_column :users, :administradora_id, :integer
  end
end
