class RemoveFotoToUsers < ActiveRecord::Migration
  def change
    remove_column :users, :foto
    add_column :users, :foto, :text
  end
end
