var handleCalendarDemo = function () {
	"use strict";
	var buttonSetting = {left: 'today prev,next ', center: 'title', right: ''};
	var date = new Date();
	var m = date.getMonth();
	var y = date.getFullYear();

	

			var calendar = $('#calendar').fullCalendar({
				header: buttonSetting,
				selectable: true,
				selectHelper: true,
				droppable: true,

				defaultView: 'agendaWeek',
				allDaySlot: false,
				firstDay: 1,
				axisFormat: 'HH:mm',
				/*timeFormat: {
				    agenda: 'HH:mm{ - HH:mm}', // ESPECIFICO PARA A VIEW AGENDAWEEK
				},*/
				timeFormat: 'HH:mm{ - HH:mm}', // PARA TODAS AS VIEWS
				minTime: 8,
				maxTime: 19,
				slotMinutes: 60,

				columnFormat: {
					month: 'ddd',
					week: 'ddd d/M',
					day: 'dddd d/M'
				},

				buttonText: {
				prev: "<span class='fc-text-arrow'>&lsaquo;</span>",
					next: "<span class='fc-text-arrow'>&rsaquo;</span>",
					prevYear: "<span class='fc-text-arrow'>&laquo;</span>",
					nextYear: "<span class='fc-text-arrow'>&raquo;</span>",
					today: 'Hoje',
					month: 'Mês',
					week: 'Semana',
					day: 'Dia'
				},

				monthNames: ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
				monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'],
				dayNames: ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'],
				dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sab'],
				

				drop: function(date, allDay) { // this function is called when something is dropped
				
					// retrieve the dropped element's stored Event Object
					var originalEventObject = $(this).data('eventObject');
					
					// we need to copy it, so that multiple events don't have a reference to the same object
					var copiedEventObject = $.extend({}, originalEventObject);
					
					// assign it the date that was reported
					copiedEventObject.start = date;
					copiedEventObject.allDay = allDay;
					
					// render the event on the calendar
					// the last `true` argument determines if the event "sticks" (http://arshaw.com/fullcalendar/docs/event_rendering/renderEvent/)
					$('#calendar').fullCalendar('renderEvent', copiedEventObject, true);
					
					// is the "remove after drop" checkbox checked?
					if ($('#drop-remove').is(':checked')) {
						// if so, remove the element from the "Draggable Events" list
						$(this).remove();
					}
					
				},
				select: function(start, end, allDay) {

					var dateTime = new Date(start);

					var dataAgendamento = $.datepicker.formatDate("yy-mm-dd", dateTime);;
					  var horaAgendamento = addZero(dateTime.getHours())+":"+addZero(dateTime.getMinutes())+":"
					  	+addZero(dateTime.getSeconds());
					  var ambiente = $('#ambiente').val();

					/*var opt = {
					        autoOpen: false,
					        modal: true,
					        width: 800,
					        height:550,
					        title: 'Cliente'
					};
					$("#newEventPopup").dialog(opt);
					$('#newEventPopup').dialog('open');*/
                    if(ambiente.length<1){
                        alert('Selecione o ambiente que deseja agendar');
                    }else{
					    location.href='/agendamentos/new?data='+dataAgendamento+'&hora='+horaAgendamento+'&ambiente='+ambiente;
                    }
                   	$("#submit").click(function(){
                   		location.href='/clientes?data=123&hora=12&pod=3';
                    /*var title=$("#cliente_nome").val();
                    if (title) {*/
                        /*calendar.fullCalendar('renderEvent',{
                            title: title,
                            start: start,
                            end: end,
                            allDay: allDay
                        },
                        true // make the event "stick"
                    );*/
                      /*  

					  

					  var data = {data:dataAgendamento, hora:horaAgendamento, cliente_id:1, 
					   funcionario_id:podologo, status:"Ausente"};

					  $.ajax({
				        type : "POST",
				        url : "/agendas",
				        data: JSON.stringify(data),
				        datatype : 'json',
				        contentType: "application/json; charset=utf-8",
				        success : function() {
				          $("#newEventPopup").dialog('close');
				          getEventos();
				        },
				        error : function(error) {
				        }
				      });

                    }
                    calendar.fullCalendar('unselect');
                    calendar.fullCalendar('refetchEvents');*/
                    

                });

					//var title = prompt('Event Title:');
					/*if (title) {
						
					  var dateTime = new Date(start);

					  var dataAgendamento = $.datepicker.formatDate("yy-mm-dd", dateTime);;
					  var horaAgendamento = addZero(dateTime.getHours())+":"+addZero(dateTime.getMinutes())+":"
					  	+addZero(dateTime.getSeconds());

					  var data = {data:dataAgendamento, hora:horaAgendamento, cliente_id:1,
					   status:"Ausente"};

					 /* $.ajax({
				        type : "POST",
				        url : "/agendas",
				        data: JSON.stringify(data),
				        datatype : 'json',
				        contentType: "application/json; charset=utf-8",
				        success : function() {
				          alert('Item successfully created!'); 
				        },
				        error : function(error) {
				        }
				      });

						calendar.fullCalendar('renderEvent',
							{
								title: title,
								start: start,
								end: end,
								allDay: allDay
							},
							true // make the event "stick"
						);
					}
					calendar.fullCalendar('unselect');*/
				},
				eventRender: function(event, element, calEvent) {
						var mediaObject = (event.media) ? event.media : '';
						var description = (event.description) ? event.description : '';
		            element.find(".fc-event-title").after($("<span class=\"fc-event-icons\"></span>").html(mediaObject));
		            element.find(".fc-event-title").append('<small>'+ description +'</small>');
		        },
				editable: true,

				eventClick: function(calEvent, jsEvent, view) {

					var r=confirm("Deseja editar o agendamento de: " + calEvent.title);
		            if (r===true){
                        location.href="/agendamentos/"+calEvent._id+"/edit"
		            }
				}
			});

	$('#ambiente').change(function(){
		getEventos();
 	});

 	function getEventos(){
 		console.log('adasda');
 		$.getJSON("/agendamentos.json?ambiente_id="+$('#ambiente').val(), function(data) {
			console.log(data);
			var evento = Array();

			for(var i=0; i < data.length; i++){
			  var ev = new Object();

			  var myDate = new Date(data[i].data);
			  myDate.setDate(myDate.getDate() + 1);
			  var myHour = new Date(data[i].hora);
			  myHour.setHours(myHour.getHours() + 1);

			  ev.id = data[i].id;
			  ev.title = data[i].user.nome;
			  ev.start = new Date(myDate.getFullYear(), myDate.getMonth(), myDate.getDate(), myHour.getHours() + 1);
			  ev.end = new Date(myDate.getFullYear(), myDate.getMonth(), myDate.getDate(), myHour.getHours() + 2);
			  ev.className = 'bg-purple';
			  ev.allDay = false;
			  evento.push(ev);

			}


			calendar.fullCalendar( 'removeEvents')
			calendar.fullCalendar( 'addEventSource', evento );
	          
         });
 	};
	
	
	/* initialize the external events
	-----------------------------------------------------------------*/
	$('#external-events .external-event').each(function() {
		var eventObject = {
			title: $.trim($(this).attr('data-title')),
			className: $(this).attr('data-bg'),
			media: $(this).attr('data-media'),
			description: $(this).attr('data-desc')
		};
		
		$(this).data('eventObject', eventObject);
		
		$(this).draggable({
			zIndex: 999,
			revert: true,
			revertDuration: 0
		});
	});
};

function addZero(i) {
    if (i < 10) {
        i = "0" + i;
    }
    return i;
}


var Calendar = function () {
	"use strict";
    return {
        //main function
        init: function () {
            handleCalendarDemo();
        }
    };
}();