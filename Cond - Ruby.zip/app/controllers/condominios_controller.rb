class CondominiosController < ApplicationController
  before_filter :auth_admin
  before_action :set_condominio, only: [:show, :edit, :update, :destroy]

  # GET /condominios
  # GET /condominios.json
  def index
    @condominios = Condominio.all


    where="id >0 "
    if params[:nome] != nil && params[:nome].length>0
      where+=" and nome like '%"+params[:nome]+"%' "
    end

    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end
    where+=" and administradora_id = "+current_user.administradora_id.to_s
    @condominios = @condominios.paginate(:page => params[:page], :per_page => 10).order('nome ASC').where(where)
  end

  # GET /condominios/1
  # GET /condominios/1.json
  def show
  end

  # GET /condominios/new
  def new
    @condominio = Condominio.new
  end

  # GET /condominios/1/edit
  def edit
  end

  # POST /condominios
  # POST /condominios.json
  def create
    @condominio = Condominio.new(condominio_params)

    respond_to do |format|
      if @condominio.save
        format.html { redirect_to condominios_path, notice: 'Condominio criado com sucesso.' }
        format.json { render :show, status: :created, location: @condominio }
      else
        format.html { render :new }
        format.json { render json: @condominio.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /condominios/1
  # PATCH/PUT /condominios/1.json
  def update
    respond_to do |format|
      if @condominio.update(condominio_params)
        format.html { redirect_to condominios_path, notice: 'Condominio editado com sucesso.' }
        format.json { render :show, status: :ok, location: @condominio }
      else
        format.html { render :edit }
        format.json { render json: @condominio.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /condominios/1
  # DELETE /condominios/1.json
  def destroy
    if(@condominio.ativo=="N")
      @condominio.update({"ativo"=>"S"})
    else
      @condominio.update({"ativo"=>"N"})
    end

    respond_to do |format|
      if(@condominio.ativo=="N")
        format.html { redirect_to condominios_url, notice: 'Condominio desativado com sucesso.' }
      else
        format.html { redirect_to condominios_url, notice: 'Condominio ativado com sucesso.' }
      end

      format.json { head :no_content }
    end
  end

  def get_cidades
    @cidades = Cidade.where("estado_id="+params[:estado_id].to_s)

  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_condominio
      @condominio = Condominio.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def condominio_params
      params.require(:condominio).permit(:nome, :cidade_id, :estado_id, :cep, :endereco, :foto, :latitude, :longitude, :condominio_id, :ativo, :administradora_id)
    end
end
