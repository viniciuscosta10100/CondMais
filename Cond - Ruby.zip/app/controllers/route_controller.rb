class RouteController < ApplicationController

  def root
    if current_user.tipo=="R"

      respond_to do |format|
        format.html { redirect_to administradoras_path, notice: 'Bem vindo(a) '+current_user.nome }
      end
    elsif current_user.tipo=="A"

      respond_to do |format|
        format.html { redirect_to condominios_path, notice: 'Bem vindo(a) '+current_user.nome }
      end
    elsif current_user.tipo=="S"

      respond_to do |format|
        format.html { redirect_to avisos_path, notice: 'Bem vindo(a) '+current_user.nome }
      end

    end
  end
end
