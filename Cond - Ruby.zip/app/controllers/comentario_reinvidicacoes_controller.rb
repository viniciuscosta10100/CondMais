class ComentarioReinvidicacoesController < ApplicationController
  before_action :set_comentario_reinvidicacao, only: [:show, :edit, :update, :destroy]
  skip_before_filter :verify_authenticity_token
  # GET /comentario_reinvidicacoes
  # GET /comentario_reinvidicacoes.json
  def index
    @comentario_reinvidicacoes = ComentarioReinvidicacao.all
  end

  # GET /comentario_reinvidicacoes/1
  # GET /comentario_reinvidicacoes/1.json
  def show
  end

  # GET /comentario_reinvidicacoes/new
  def new
    @comentario_reinvidicacao = ComentarioReinvidicacao.new
  end

  # GET /comentario_reinvidicacoes/1/edit
  def edit
  end

  # POST /comentario_reinvidicacoes
  # POST /comentario_reinvidicacoes.json
  def create
    @comentario_reinvidicacao = ComentarioReinvidicacao.new(comentario_reinvidicacao_params)

    userComentario = User.find(@comentario_reinvidicacao.user_id)

    reinvidicacao = Reinvidicacao.find(@comentario_reinvidicacao.reinvidicacao_id)

    respond_to do |format|
      if @comentario_reinvidicacao.save

        if @comentario_reinvidicacao.concluido
          reinvidicacao.update({"status"=>"C"})
          format.json { render :json => '{"result":"true","message":"Mensagem enviada com sucesso."}' }
        else
          if userComentario.tipo=="S"

            if reinvidicacao.user.tipo=="M"
              reinvidicacao.update({"status"=>"M"})

              users = User.where("tipo='M' and ativo='S' and id="+reinvidicacao.user_id.to_s)

              users.each do |user|
                if user.gcm !=nil && user.gcm !=""
                  puts "USER ANDROID"
                  gcm = GCM.new("AIzaSyDYjNfUFujEuCSrnIJF7GfeWGOs0GvH7Iw")

                  registration_ids = Array.new
                  registration_ids << user.gcm
                  puts "quantidade de ids"+registration_ids.length.to_s
                  puts "#{registration_ids}"
                  options = {data: {tipo: "resposta_reinvidicacao",mensage: reinvidicacao.mensagem,reinvidicacao_id: reinvidicacao.id}}
                  response = gcm.send(registration_ids, options)
                  puts response
                end
              end

              format.json { render :json => '{"result":"true","message":"Mensagem enviada com sucesso."}' }

            elsif reinvidicacao.user.tipo=="S"
              reinvidicacao.update({"status"=>"A"})
              format.json { render :json => '{"result":"true","message":"Mensagem enviada com sucesso."}' }
            end


          elsif userComentario.tipo=="M"

            reinvidicacao.update({"status"=>"S"})
            format.json { render :json => '{"result":"true","message":"Mensagem enviada com sucesso."}' }
          elsif userComentario.tipo=="A"

            reinvidicacao.update({"status"=>"S"})

            users = User.where("ativo='S' and id="+reinvidicacao.user_id.to_s)

            users.each do |user|
              if user.gcm !=nil && user.gcm !=""
                puts "USER ANDROID"
                gcm = GCM.new("AIzaSyDYjNfUFujEuCSrnIJF7GfeWGOs0GvH7Iw")

                registration_ids = Array.new
                registration_ids << user.gcm
                puts "quantidade de ids"+registration_ids.length.to_s
                puts "#{registration_ids}"
                options = {data: {tipo: "resposta_reinvidicacao",mensage: reinvidicacao.mensagem,reinvidicacao_id: reinvidicacao.id}}
                response = gcm.send(registration_ids, options)
                puts response
              end

            end

            format.html { redirect_to reinvidicacao_path(reinvidicacao), notice: 'Mensagem enviada com sucesso.' }
            format.json { render :show, status: :created, location: @comentario_reinvidicacao }

          end
        end

      else
        format.html { render :new }
        format.json { render :json => '{"result":"false","message":"Erro ao enviar mensage, tente novamente em instantes."}' }
      end
    end
  end

  # PATCH/PUT /comentario_reinvidicacoes/1
  # PATCH/PUT /comentario_reinvidicacoes/1.json
  def update
    respond_to do |format|
      if @comentario_reinvidicacao.update(comentario_reinvidicacao_params)
        format.html { redirect_to @comentario_reinvidicacao, notice: 'Comentario reinvidicacao was successfully updated.' }
        format.json { render :show, status: :ok, location: @comentario_reinvidicacao }
      else
        format.html { render :edit }
        format.json { render json: @comentario_reinvidicacao.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /comentario_reinvidicacoes/1
  # DELETE /comentario_reinvidicacoes/1.json
  def destroy
    @comentario_reinvidicacao.destroy
    respond_to do |format|
      format.html { redirect_to comentario_reinvidicacoes_url, notice: 'Comentario reinvidicacao was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_comentario_reinvidicacao
    @comentario_reinvidicacao = ComentarioReinvidicacao.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def comentario_reinvidicacao_params
    params.require(:comentario_reinvidicacao).permit(:reinvidicacao_id, :mensagem, :user_id, :concluido)
  end
end
