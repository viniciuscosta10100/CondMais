class MensagensController < ApplicationController
  skip_before_filter :verify_authenticity_token
  def index
    if request.format != "application/json"
      sql = "select * from (select m.remetente_id,m.destinatario_id,m.id from mensagens m where m.remetente_id="+current_user.id.to_s+" or m.destinatario_id="+current_user.id.to_s+" order by m.id desc) as q group by destinatario_id,remetente_id order by id desc "
    else
      sql = "select * from (select m.remetente_id,m.destinatario_id,m.id from mensagens m where m.remetente_id="+params[:user_id].to_s+" or m.destinatario_id="+params[:user_id].to_s+" order by m.id desc) as q group by destinatario_id,remetente_id order by id desc "
    end
    puts sql
    connection = ActiveRecord::Base.connection

    @result = connection.execute(sql)

    @usuarios = User.all

    mensagens =Array.new
    @result.each(:as => :hash) do |row|
      destinatario_id=row["destinatario_id"]
      remetente_id=row["remetente_id"]
      id=row["id"]
      remetente = User.find(remetente_id)
      destinatario_id = User.find(destinatario_id)
      mensagem = Mensagem.find(id)

      mensagens << mensagem

    end
    @mensagens =Array.new
    mensagens.each do |mensagem|
      isEnable=true
      @mensagens.each do |msg|
        if params[:user_id].to_s==mensagem.remetente_id.to_s
          #VALIDAR DESTINATARIO NA MENSAGEM
          if params[:user_id].to_s==msg.remetente_id.to_s
            #VALIDAR DESTINATARIO NA MSG
            if msg.destinatario_id.to_s==mensagem.destinatario_id.to_s
              isEnable=false
            end
          else
            #VALIDAR REMETENTE NA MSG
            if msg.remetente_id.to_s==mensagem.destinatario_id.to_s
              isEnable=false
            end
          end
        else
          #VALIDAR REMETENTE NA MENSAGEM

          if params[:user_id].to_s==msg.remetente_id.to_s
            #VALIDAR DESTINATARIO NA MSG
            puts "validando destinatario na msg: msg.destinatario="+msg.destinatario_id.to_s+" - mensagem.remetente_id="+mensagem.remetente_id.to_s
            if msg.destinatario_id.to_s==mensagem.remetente_id.to_s
              isEnable=false
            end
          else
            #VALIDAR REMETENTE NA MSG
            if msg.remetente_id.to_s==mensagem.remetente_id.to_s
              isEnable=false
            end
          end
        end

      end

      if isEnable
        @mensagens << mensagem
      end
    end
  end

  def getMensagens
    user_id = params[:user_id]
    vizinho_id = params[:vizinho_id]

    @mensagens = Mensagem.where('(remetente_id='+user_id.to_s+' and destinatario_id='+vizinho_id.to_s+') OR (remetente_id='+vizinho_id.to_s+' and destinatario_id='+user_id.to_s+')').order('id desc')
  end

  def show
    if request.format =="application/json"
      user_id = params[:user_id]
      vizinho_id = params[:vizinho_id]
    else
      user_id = current_user.id
      vizinho_id = params[:id]

     @user = User.find(user_id)
    end

    if request.format =="application/json"
      @mensagens = Mensagem.where('(remetente_id='+user_id.to_s+' and destinatario_id='+vizinho_id.to_s+') OR (remetente_id='+vizinho_id.to_s+' and destinatario_id='+user_id.to_s+')').order('id desc')
    else
      @mensagens = Mensagem.where('(remetente_id='+user_id.to_s+' and destinatario_id='+vizinho_id.to_s+') OR (remetente_id='+vizinho_id.to_s+' and destinatario_id='+user_id.to_s+')').order('id desc')
    end
  end

  def sendMsg
    require 'gcm'
    require 'houston'
    remetente_id =params[:remetente_id]
    destinatario_id =params[:destinatario_id]
    texto =params[:mensagem]

    userRemetente = User.find(params[:remetente_id])
    mensagem = Mensagem.new
    mensagem.texto=texto
    mensagem.remetente_id=remetente_id
    mensagem.destinatario_id=destinatario_id

    respond_to do |format|
      if mensagem.save

        users = User.where("id="+destinatario_id.to_s)

        users.each do |user|

          if user.gcm !=nil && user.gcm !=""
            gcm = GCM.new("AIzaSyDYjNfUFujEuCSrnIJF7GfeWGOs0GvH7Iw")

            registration_ids = Array.new
            registration_ids << user.gcm
            puts "quantidade de ids"+registration_ids.length.to_s
            puts "#{registration_ids}"
            #registration_ids= ["APA91bH5z7HhEIixTAFjNqCt15LImtVzPmpXmrc4Ic60WXIRPkeGxgvjXG3BEcfkrK4M72WsMt9310vJckqcarSIGMLyoY67AygXvt0ZqNoIKjpYI_BSAOdUo-L2DnGguHJ4c6D6TPLW"] # an array of one or more client registration IDs
            options = {data: {tipo: "nova_mensagem",mensagem: userRemetente.nome.to_s+": "+texto, user_id:destinatario_id, remetente_id:remetente_id }}
            response = gcm.send(registration_ids, options)
            puts response
          end
        end
        format.json { render :json => '{"result":"true","message":"Mensagem enviada com sucesso."}' }
      else
        format.json { render :json => '{"result":"false","message":"Erro em enviar mensagem"}' }
      end
    end
  end
  def save
    require 'gcm'
    require 'houston'
    user_id =params[:user_id]
    texto =params[:mensagem]

    mensagem = Mensagem.new
    mensagem.destinatario_id=user_id
    mensagem.texto=texto
    #mensagem.isSindico='S'
    mensagem.condominio_id=current_user.condominio_id

    respond_to do |format|
      if mensagem.save
        users = User.where("id="+user_id.to_s)

        users.each do |user|

          if user.gcm !=nil && user.gcm !=""
            gcm = GCM.new("AIzaSyDYjNfUFujEuCSrnIJF7GfeWGOs0GvH7Iw")

            registration_ids = Array.new
            registration_ids << user.gcm
            puts "quantidade de ids"+registration_ids.length.to_s
            puts "#{registration_ids}"
            #registration_ids= ["APA91bH5z7HhEIixTAFjNqCt15LImtVzPmpXmrc4Ic60WXIRPkeGxgvjXG3BEcfkrK4M72WsMt9310vJckqcarSIGMLyoY67AygXvt0ZqNoIKjpYI_BSAOdUo-L2DnGguHJ4c6D6TPLW"] # an array of one or more client registration IDs
            options = {data: {tipo: "mensagem_sindico",mensagem: "Sindico: "+texto }}
            response = gcm.send(registration_ids, options)
            puts response
          end
        end
        format.html { redirect_to '/mensagens/'+user_id.to_s, notice: 'Mensagem enviada com sucesso.' }
        format.json { render :show, status: :created, location: mensagem }
      else
        format.html { render :new }
        format.json { render json: mensagem.errors, status: :unprocessable_entity }
      end
    end
  end
end
