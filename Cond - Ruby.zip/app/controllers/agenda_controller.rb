class AgendaController < ApplicationController

  def index

  end
end
