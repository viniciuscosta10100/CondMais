class AvisosController < ApplicationController
  before_action :set_aviso, only: [:show, :edit, :update, :destroy]
  skip_before_filter :verify_authenticity_token, only: [:sendAviso,:resend,:desativar]
  # GET /avisos
  # GET /avisos.json
  def index
    @avisos = Aviso.all


    where="id >0 "
    if params[:tipo] != nil && params[:tipo].length>0
      where+=" and tipo="+params[:tipo].to_s
    end



    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end
    if request.format !="application/json"
      where+=" and administradora_id = " + current_user.administradora_id.to_s+" "
      @avisos = @avisos.paginate(:page => params[:page], :per_page => 10).order('created_at desc').where(where)
    else
      where+=" and ativo = 'S' "
      @avisos = @avisos.order('created_at desc').where(where)
    end

  end

  # GET /avisos/1
  # GET /avisos/1.json
  def show
  end

  # GET /avisos/new
  def new
    @aviso = Aviso.new
  end

  # GET /avisos/1/edit
  def edit
  end

  def resend
    @aviso = Aviso.find(params[:aviso_id])
    require 'gcm'
    require 'houston'


    puts "REENVIANDO AVISO"

    respond_to do |format|


        users = User.where("tipo='M' and ativo='S' and condominio_id="+@aviso.condominio_id.to_s)

        users.each do |user|
          if user.gcm !=nil && user.gcm !=""
            puts "USER ANDROID"
            gcm = GCM.new("AIzaSyDYjNfUFujEuCSrnIJF7GfeWGOs0GvH7Iw")

            registration_ids = Array.new
            registration_ids << user.gcm
            puts "quantidade de ids"+registration_ids.length.to_s
            puts "#{registration_ids}"
            #registration_ids= ["APA91bH5z7HhEIixTAFjNqCt15LImtVzPmpXmrc4Ic60WXIRPkeGxgvjXG3BEcfkrK4M72WsMt9310vJckqcarSIGMLyoY67AygXvt0ZqNoIKjpYI_BSAOdUo-L2DnGguHJ4c6D6TPLW"] # an array of one or more client registration IDs
            options = {data: {tipo: "aviso",mensagem: @aviso.mensagem,aviso_id: @aviso.id}}
            response = gcm.send(registration_ids, options)
            puts response
          end
        end


        format.html { redirect_to avisos_path, notice: 'Aviso reenviado com sucesso.' }
        format.json { render :json => '{"result":"true","message":"Aviso reenviada com sucesso."}' }

    end
  end

  def sendAviso
    require 'gcm'
    require 'houston'
    @aviso = Aviso.new
    condominio = Condominio.find(params[:condominio_id])
    user = User.find(params[:user_id])

    @aviso.user_id=params[:user_id]
    @aviso.mensagem=params[:mensagem]
    @aviso.condominio_id=params[:condominio_id]

    @aviso.administradora_id=condominio.administradora_id
    @aviso.remetente="Sindico: "+user.nome;
    respond_to do |format|
      if @aviso.save

        users = User.where("tipo='M' and ativo='S' and condominio_id="+@aviso.condominio_id.to_s)

        users.each do |user|
          if user.gcm !=nil && user.gcm !=""
            gcm = GCM.new("AIzaSyDYjNfUFujEuCSrnIJF7GfeWGOs0GvH7Iw")

            registration_ids = Array.new
            registration_ids << user.gcm
            puts "quantidade de ids"+registration_ids.length.to_s
            puts "#{registration_ids}"
            #registration_ids= ["APA91bH5z7HhEIixTAFjNqCt15LImtVzPmpXmrc4Ic60WXIRPkeGxgvjXG3BEcfkrK4M72WsMt9310vJckqcarSIGMLyoY67AygXvt0ZqNoIKjpYI_BSAOdUo-L2DnGguHJ4c6D6TPLW"] # an array of one or more client registration IDs
            options = {data: {tipo: "aviso",mensagem: @aviso.mensagem,aviso_id: @aviso.id}}
            response = gcm.send(registration_ids, options)
            puts response
          end
        end


        format.json { render :json => '{"result":"true","message":"Aviso enviada com sucesso."}' }
      else
        format.json { render :json => '{"result":"false","message":"Erro ao enviar."}' }
      end
    end
  end
  # POST /avisos
  # POST /avisos.json
  def create
    @aviso = Aviso.new(aviso_params)
    require 'gcm'
    require 'houston'

    @aviso.user_id=current_user.id
    if current_user.tipo=='S'
      @aviso.remetente="Sindico: "+current_user.nome;
    elsif current_user.tipo=='A'
      admin = Administradora.find(current_user.administradora_id)
      @aviso.remetente=admin.nome;
    end
    respond_to do |format|
      if @aviso.save

        users = User.where("tipo='M' and ativo='S' and condominio_id="+@aviso.condominio_id.to_s)

        users.each do |user|
          if user.gcm !=nil && user.gcm !=""
            gcm = GCM.new("AIzaSyDYjNfUFujEuCSrnIJF7GfeWGOs0GvH7Iw")

            registration_ids = Array.new
            registration_ids << user.gcm
            options = {data: {tipo: "aviso",mensagem: @aviso.mensagem,tipo2: @aviso.tipo,aviso_id: @aviso.id}}
            response = gcm.send(registration_ids, options)
            puts response
          end
        end


        format.html { redirect_to avisos_path, notice: 'Aviso criado com sucesso.' }
        format.json { render :show, status: :created, location: @aviso }
      else
        format.html { render :new }
        format.json { render json: @aviso.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /avisos/1
  # PATCH/PUT /avisos/1.json
  def update
    respond_to do |format|
      if @aviso.update(aviso_params)
        format.html { redirect_to avisos_path, notice: 'Aviso editado com sucesso.' }
        format.json { render :show, status: :ok, location: @aviso }
      else
        format.html { render :edit }
        format.json { render json: @aviso.errors, status: :unprocessable_entity }
      end
    end
  end


  def desativar
    @aviso = Aviso.find(params[:aviso_id])
    @aviso.update({"ativo"=>"N"})

    respond_to do |format|
      if(@aviso.ativo=="N")
        format.html { redirect_to avisos_url, notice: 'Aviso desativado com sucesso.' }
        format.json { render :json => '{"result":"true","message":"Aviso desativado com sucesso."}' }
      else
        format.json { render :json => '{"result":"false","message":"Falha em desativar aviso, tente novamente em instantes."}' }
      end


    end
  end
  # DELETE /avisos/1
  # DELETE /avisos/1.json
  def destroy
    if(@aviso.ativo=="N")
      @aviso.update({"ativo"=>"S"})
    else
      @aviso.update({"ativo"=>"N"})
    end

    respond_to do |format|
      if(@aviso.ativo=="N")
        format.html { redirect_to avisos_url, notice: 'Aviso desativado com sucesso.' }
      else
        format.html { redirect_to avisos_url, notice: 'Aviso ativado com sucesso.' }
      end

      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_aviso
      @aviso = Aviso.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def aviso_params
      params.require(:aviso).permit(:mensagem, :user_id, :condominio_id, :administradora_id)
    end
end
