class UsersController < ApplicationController
  before_action :auth_root, only: [:show,:usuarios]
  before_action :auth_admin, only: [:show,:administradores]
  before_action :auth_admin, only: [:show,:sindicos]
  skip_before_filter :verify_authenticity_token, only: [:verifyCadastro,:cadastroMembro, :alterar_usuario, :logout]

  def verifyCadastro

    cpf=params[:cpf]

    users = User.where("cpf ='"+cpf.to_s+"' and ativo='S'")

    if users.length >0
      respond_to do |format|
        format.json { render :json => '{"result":"false","message":"Cpf ja cadastrado, contate a administradora."}' }
      end
    else
      @residencia = Residencia.where("cpf_titular='"+cpf.to_s+"'").first

      if @residencia==nil

        membros =Membro.where("cpf ='"+cpf.to_s+"'")

        if membros.length >0
          titular = User.find(membros.first.user_id)
          @residencia=titular.residencia
          respond_to do |format|
            format.json { render :showResidencia, status: :ok, location: @residencia }
          end

        else
          respond_to do |format|
            format.json { render :json => '{"result":"false","message":"Cpf não encontrado."}' }
          end
        end


      else
        respond_to do |format|
          format.json { render :showResidencia, status: :ok, location: @residencia }
        end
      end

    end

  end

  def logout
    user = User.find(params[:id])
    user.update({"gcm"=>""})

    user.save!(:validate => false)

    render :json => '{"result":"true","message":"Logout realizado com sucesso."}'


  end

  def cadastroMembro
    cpf=params[:cpf]
    user_id=params[:user_id]

    membro = Membro.new
    membro.cpf=cpf
    membro.user_id=user_id



    membros =Membro.where("cpf ='"+cpf.to_s+"'")

    respond_to do |format|
      if membros.length >0
        format.json { render :json => '{"result":"false","message":"Membro ja cadastrado."}' }
      else
        if membro.save
          format.json { render :json => '{"result":"true","message":"Membro cadastrado com sucesso. O mesmo deve realizar o cadastro pelo aplicativo."}' }
        else
          format.json { render :json => '{"result":"false","message":"Erro inesperado."}' }
        end
      end
    end
  end

  def alterarMorador
    cpf=params[:cpf]
    user_id=params[:user_id]

    membro = Membro.new
    membro.cpf=cpf
    membro.user_id=user_id



    membros =Membro.where("cpf ='"+cpf.to_s+"'")

    respond_to do |format|
      if membros.length >0
        format.json { render :json => '{"result":"false","message":"Membro ja cadastrado."}' }
      else
        if membro.save
          format.json { render :json => '{"result":"true","message":"Membro cadastrado com sucesso. O mesmo deve realizar o cadastro pelo aplicativo."}' }
        else
          format.json { render :json => '{"result":"false","message":"Erro inesperado."}' }
        end
      end
    end
  end

  def showResidencia

  end
  def usuarios

    @usuarios = User.all


    where=""
    if params[:nome] != nil && params[:nome].length>0
      where+=" and nome like '%"+params[:nome]+"%' "
    end

    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end
    @usuarios = User.paginate(:page => params[:page], :per_page => 10).order('nome ASC').where("tipo='R'"+where)

  end

  def moradores
    @usuarios = User.all


    where="id>0 "
    if params[:residencia_id] != nil && params[:residencia_id].length>0
      where+=" and residencia_id ="+params[:residencia_id].to_s
    end
    if params[:nome] != nil && params[:nome].length>0
      where+=" and nome like '%"+params[:nome]+"%' "
    end
    if params[:condominio_id] != nil && params[:condominio_id].length>0
      where+=" and condominio_id ="+params[:condominio_id].to_s
    end
    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end
    if request.format =="application/json"
      puts where
      @usuarios = User.where(where).order('tipo desc, nome ASC')
    else
      @usuarios = User.paginate(:page => params[:page], :per_page => 10).order('nome ASC').where("tipo='M'"+where)
    end

  end

  def administradores

    @usuarios = User.all



    where=""
    if params[:nome] != nil && params[:nome].length>0
      where+=" and nome like '%"+params[:nome]+"%' "
    end

    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end

    if current_user.tipo=='A'
      where+=" and administradora_id = "+current_user.administradora_id.to_s
    end
    @usuarios = User.paginate(:page => params[:page], :per_page => 10).order('nome ASC').where("tipo='A'"+where)

  end

  def sindicos

    @usuarios = User.all



    where=""
    if params[:nome] != nil && params[:nome].length>0
      where+=" and nome like '%"+params[:nome]+"%' "
    end

    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end

    @usuarios = User.paginate(:page => params[:page], :per_page => 10).order('nome ASC').where("tipo='S' and administradora_id = "+current_user.administradora_id.to_s)

  end

  def alterar_usuario
    puts ""
    @user = User.find(params["user"]["id"])

    respond_to do |format|
      @user.update({
                       "nome"=>params["user"]["nome"],
                       "telefone"=>params["user"]["telefone"],
                       "sexo"=>params["user"]["sexo"],
                       "foto"=>params["user"]["foto"]
                   })
      format.json { render :json => '{"result":"true","message":"Usuario atualizado com sucesso."}' }
    end
  end
end
