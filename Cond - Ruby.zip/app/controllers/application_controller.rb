class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  protect_from_forgery with: :exception


  before_filter :update_sanitized_params, if: :devise_controller?
  def update_sanitized_params
    devise_parameter_sanitizer.for(:sign_up) {|u| u.permit(:nome,:cpf,:tipo,:telefone,:foto,:residencia_id,:administradora_id,:condominio_id,:email,:password,:password_confirmation,:unconfirmed_email)}
    devise_parameter_sanitizer.for(:account_update) {|u| u.permit(:nome,:cpf,:tipo,:telefone,:foto,:residencia_id,:administradora_id,:condominio_id,:password,:password_confirmation,:unconfirmed_email,:current_password)}
  end


  def auth_root
    auth
    if current_user !=nil
      if current_user.tipo!="R"

        respond_to do |format|
          format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina.' }
        end
      end
    else
      respond_to do |format|
        format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina.' }
      end
    end

  end

  def auth_admin

    if request.format !="application/json"
      if current_user !=nil
        auth
        if current_user.tipo!="A" && current_user.tipo!="R"
          respond_to do |format|
            format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina.' }
          end
        else
          if current_user.tipo!="R"
            administradora = Administradora.find(current_user.administradora_id)

            if(administradora.ativo=="N")
              sign_out current_user
              respond_to do |format|
                format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina. Administradora desativada.' }
              end
            end
          end
        end
      else
        respond_to do |format|
          format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina.' }
        end
      end
    end


  end

  def auth
    if current_user==nil || current_user.ativo=="N" || current_user.tipo=="M"
      sign_out current_user
      respond_to do |format|
        format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina. ' }
      end
    end
  end
end
