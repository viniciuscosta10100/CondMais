class ReinvidicacoesController < ApplicationController
  before_filter :auth_admin
  before_action :set_reinvidicacao, only: [:show, :edit, :update, :destroy]
  skip_before_filter :verify_authenticity_token

  # GET /reinvidicacoes
  # GET /reinvidicacoes.json
  def index
    @reinvidicacoes = Reinvidicacao.all

    where=""

    if params[:user_id]!=nil
      where+=" and user_id="+params[:user_id].to_s+" "
    end
    if params[:condominio_id]!=nil
      where+=" and condominio_id="+params[:condominio_id].to_s+" "
    end
    if request.format !="application/json"

      @reinvidicacoes = Reinvidicacao.joins(:user).paginate(:page => params[:page], :per_page => 10).where("users.tipo='S' and reinvidicacoes.administradora_id= "+current_user.administradora_id.to_s+where).order('created_at desc')
    else

      puts where

      user = User.find(params[:user_id])

      if user.tipo=="S"
        where=" and condominio_id="+user.condominio_id.to_s
      end

      @reinvidicacoes = Reinvidicacao.where("id>0 "+where).order('created_at desc')
    end
  end

  # GET /reinvidicacoes/1
  # GET /reinvidicacoes/1.json
  def show
    @comentario_reinvidicacao = ComentarioReinvidicacao.new
  end

  # GET /reinvidicacoes/new
  def new
    @reinvidicacao = Reinvidicacao.new
  end

  # GET /reinvidicacoes/1/edit
  def edit
  end

  # POST /reinvidicacoes
  # POST /reinvidicacoes.json
  def create
    #STATUS
    #A- Aguardando resposta da Administradora
    #S- Aguardando resposta do Sindico
    #C- CONCLUIDO
    #M- Aguardando resposta do Morador

    @reinvidicacao = Reinvidicacao.new(reinvidicacao_params)
    #@reinvidicacao.status="A"
    condominio = Condominio.find(@reinvidicacao.condominio_id)
    @reinvidicacao.administradora_id=condominio.administradora_id
    respond_to do |format|
      if @reinvidicacao.save
        format.json { render :json => '{"result":"true","message":"Reinvidicação criada com sucesso."}' }
      else
        format.json { render :json => '{"result":"false","message":"Falha em criar reinvidicação."}' }
      end
    end
  end

  # PATCH/PUT /reinvidicacoes/1
  # PATCH/PUT /reinvidicacoes/1.json
  def update
    respond_to do |format|
      if @reinvidicacao.update(reinvidicacao_params)
        format.html { redirect_to @reinvidicacao, notice: 'Reinvidicacao was successfully updated.' }
        format.json { render :show, status: :ok, location: @reinvidicacao }
      else
        format.html { render :edit }
        format.json { render json: @reinvidicacao.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /reinvidicacoes/1
  # DELETE /reinvidicacoes/1.json
  def destroy
    @reinvidicacao.destroy
    respond_to do |format|
      format.html { redirect_to reinvidicacoes_url, notice: 'Reinvidicacao was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_reinvidicacao
      @reinvidicacao = Reinvidicacao.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def reinvidicacao_params
      params.require(:reinvidicacao).permit(:foto, :mensagem, :user_id, :status,:administradora_id, :condominio_id)
    end
end
