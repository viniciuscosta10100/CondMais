class AdministradorasController < ApplicationController
  before_filter :auth_root
  before_action :set_administradora, only: [:show, :edit, :update, :destroy]

  # GET /administradoras
  # GET /administradoras.json
  def index
    @administradoras = Administradora.all

    if params[:nome] != nil && params[:nome].length>0
      where+=" and nome like '%"+params[:nome]+"%' "

    end

    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end

    @administradoras = @administradoras.paginate(:page => params[:page], :per_page => 10).order('nome ASC').where(where)
  end

  # GET /administradoras/1
  # GET /administradoras/1.json
  def show
  end

  # GET /administradoras/new
  def new
    @administradora = Administradora.new
  end

  # GET /administradoras/1/edit
  def edit
  end

  # POST /administradoras
  # POST /administradoras.json
  def create
    @administradora = Administradora.new(administradora_params)

    respond_to do |format|
      if @administradora.save
        format.html { redirect_to administradoras_path, notice: 'Administradora criada com sucesso.' }
        format.json { render :show, status: :created, location: @administradora }
      else
        format.html { render :new }
        format.json { render json: @administradora.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /administradoras/1
  # PATCH/PUT /administradoras/1.json
  def update
    respond_to do |format|
      if @administradora.update(administradora_params)
        format.html { redirect_to administradoras_path, notice: 'Administradora editada com sucesso.' }
        format.json { render :show, status: :ok, location: @administradora }
      else
        format.html { render :edit }
        format.json { render json: @administradora.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /administradoras/1
  # DELETE /administradoras/1.json
  def destroy
    if(@administradora.ativo=="N")
      @administradora.update({"ativo"=>"S"})
    else
      @administradora.update({"ativo"=>"N"})
    end

    respond_to do |format|
      if(@administradora.ativo=="N")
        format.html { redirect_to administradoras_url, notice: 'Administradora desativada com sucesso.' }
      else
        format.html { redirect_to administradoras_url, notice: 'Administradora ativada com sucesso.' }
      end

      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_administradora
      @administradora = Administradora.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def administradora_params
      params.require(:administradora).permit(:nome, :cnpj, :ativo, :logo)
    end
end
