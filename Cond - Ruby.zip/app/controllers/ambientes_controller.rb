class AmbientesController < ApplicationController
  before_filter :auth_admin
  before_action :set_ambiente, only: [:show, :edit, :update, :destroy]

  # GET /ambientes
  # GET /ambientes.json
  def index
    @ambientes = Ambiente.all


    where="id >0 "
    if params[:nome] != nil && params[:nome].length>0
      where+=" and nome like '%"+params[:nome]+"%' "
    end

    if params[:condominio_id] != nil && params[:condominio_id].length>0
      where+=" and condominio_id = "+params[:condominio_id].to_s
    end

    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end
    if request.format !="application/json"
      where+=" and administradora_id = " + current_user.administradora_id.to_s+" "
      @ambientes = @ambientes.paginate(:page => params[:page], :per_page => 10).order('nome ASC').where(where)
    else
      @ambientes = @ambientes.where(where).order('nome ASC')
    end

  end

  # GET /ambientes/1
  # GET /ambientes/1.json
  def show
  end

  # GET /ambientes/new
  def new
    @ambiente = Ambiente.new
  end

  # GET /ambientes/1/edit
  def edit
  end

  # POST /ambientes
  # POST /ambientes.json
  def create
    @ambiente = Ambiente.new(ambiente_params)

    respond_to do |format|
      if @ambiente.save
        format.html { redirect_to ambientes_path, notice: 'Ambiente criado com sucesso.' }
        format.json { render :show, status: :created, location: @ambiente }
      else
        format.html { render :new }
        format.json { render json: @ambiente.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /ambientes/1
  # PATCH/PUT /ambientes/1.json
  def update
    respond_to do |format|
      if @ambiente.update(ambiente_params)
        format.html { redirect_to ambientes_path, notice: 'Ambiente editado com sucesso.' }
        format.json { render :show, status: :ok, location: @ambiente }
      else
        format.html { render :edit }
        format.json { render json: @ambiente.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /ambientes/1
  # DELETE /ambientes/1.json
  def destroy
    if(@ambiente.ativo=="N")
      @ambiente.update({"ativo"=>"S"})
    else
      @ambiente.update({"ativo"=>"N"})
    end

    respond_to do |format|
      if(@ambiente.ativo=="N")
        format.html { redirect_to ambientes_url, notice: 'Ambiente desativado com sucesso.' }
      else
        format.html { redirect_to ambientes_url, notice: 'Ambiente ativado com sucesso.' }
      end

      format.json { head :no_content }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_ambiente
    @ambiente = Ambiente.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def ambiente_params
    params.require(:ambiente).permit(:nome, :condominio_id, :ativo, :administradora_id)
  end
end
