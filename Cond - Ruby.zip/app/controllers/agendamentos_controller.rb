class AgendamentosController < ApplicationController
  before_action :set_agendamento, only: [:show, :edit, :update, :destroy]
  skip_before_filter :verify_authenticity_token
  # GET /agendamentos
  # GET /agendamentos.json
  def index
    where=""
    if params[:ambiente_id]!=nil
      ambiente=params[:ambiente_id]
      where+=" and ambiente_id="+ambiente.to_s+" "
    end

    if params[:data]!=nil
      where+=" and data='"+params[:data].to_s+"' "
    end

    if params[:user_id]!=nil
      where+=" and user_id="+params[:user_id].to_s+" "
      end
    if params[:condominio_id]!=nil
      where+=" and condominio_id="+params[:condominio_id].to_s+" "
    end
    if request.format !="application/json"
      @ambientes = Ambiente.where("ativo='S' and condominio_id= "+current_user.condominio_id.to_s+where)
    else
      puts where
      @agendamentos = Agendamento.where("id>0 "+where).order('created_at desc,hora desc')
    end


  end

  # GET /agendamentos/1
  # GET /agendamentos/1.json
  def show
  end

  # GET /agendamentos/new
  def new
    @agendamento = Agendamento.new
  end

  # GET /agendamentos/1/edit
  def edit
  end

  # POST /agendamentos
  # POST /agendamentos.json
  def create
    @agendamento = Agendamento.new(agendamento_params)
    # @agendamento.hora=Time.mktime(@agendamento.data.year, @agendamento.data.month, @agendamento.data.day, @agendamento.hora.hour-5, @agendamento.hora.min)

    agendamentos=Agendamento.where("data='"+@agendamento.data.to_s+"' and ambiente_id="+@agendamento.ambiente_id.to_s+" and hora='"+@agendamento.hora.strftime("%H:%M:%S")+"'")

    if agendamentos.length >0
      respond_to do |format|
        format.json { render :json => '{"result":"false","message":"Este horario ja foi reservado."}' }
      end
    else
      respond_to do |format|
        if @agendamento.save
          format.html { redirect_to agendamentos_path, notice: 'Agendamento criado com sucesso.' }
          format.json { render :json => '{"result":"true","message":"Reserva criada com sucesso."}' }
        else
          format.html { render :new }
          format.json { render :json => '{"result":"false","message":"Erro inesperado, tente em instantes."}' }
        end
      end
    end

  end

  # PATCH/PUT /agendamentos/1
  # PATCH/PUT /agendamentos/1.json
  def update
    respond_to do |format|
      if @agendamento.update(agendamento_params)
        format.html { redirect_to agendamentos_path, notice: 'Agendamento editado com sucesso.' }
        format.json { render :show, status: :ok, location: @agendamento }
      else
        format.html { render :edit }
        format.json { render json: @agendamento.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /agendamentos/1
  # DELETE /agendamentos/1.json
  def destroy
    @agendamento.destroy
    respond_to do |format|
      format.html { redirect_to agendamentos_url, notice: 'Agendamento removido com sucesso.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_agendamento
      @agendamento = Agendamento.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def agendamento_params
      params.require(:agendamento).permit(:user_id, :data, :hora, :ambiente_id)
    end
end
