class RegistrationsController < Devise::RegistrationsController
  skip_before_filter :require_no_authentication
  skip_before_filter :verify_authenticity_token
  layout 'application.html.erb'
  def new
    if current_user ==nil
      respond_to do |format|
        format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina.' }
      end
    else

      tipo = params[:tipo]

      if tipo!='R' && tipo!='A' && tipo!='S' && tipo!='P'
        respond_to do |format|
          format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina.' }
        end
      else



        if current_user.tipo!='R'
          if tipo=='R'
            respond_to do |format|
              format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina.' }
            end
          else
            build_resource({})
            set_minimum_password_length
            yield resource if block_given?
            respond_with self.resource
          end
        elsif current_user.tipo=='S' || current_user.tipo=='P'
          respond_to do |format|
            format.html { redirect_to '/', notice: 'Você não tem permissão para acessar esta pagina.' }
          end
        else
          build_resource({})
          set_minimum_password_length
          yield resource if block_given?
          respond_with self.resource
        end

      end

    end


  end

  def create
    if request.format =="application/json"
      puts "SAVING MORADOR"

      build_resource(sign_up_params)
      puts ""
      @user =resource

      residencia = Residencia.find(@user.residencia_id)

      @user.condominio_id=residencia.condominio_id
      @user.administradora_id=residencia.administradora_id

      @user.tipo='M'
      respond_to do |format|
        @user.save
        if @user.save!(:validate => false)

          format.json { render :json => '{"result":"true","message":"Usuario cadastrado com sucesso."}' }
        else
          clean_up_passwords resource
          set_minimum_password_length
          format.html { render :new }
          format.json { render :json => '{"result":"false","message":"Preencha todos os campos."}' }
        end
      end
    else

        puts "SAVING USER"
        build_resource(sign_up_params)
        puts ""
        @user =resource

        respond_to do |format|
          @user.save
          if @user.save!(:validate => false)
            if @user.tipo=='R'
              format.html { redirect_to '/usuarios', notice: 'Usuarios cadastrado com sucesso.' }
            elsif @user.tipo=='S'
              format.html { redirect_to '/sindicos', notice: 'Sindico cadastrado com sucesso.' }
            elsif @user.tipo=='A'
              format.html { redirect_to '/administradores', notice: 'Administrador cadastrado com sucesso.' }
            end
            format.json { render :json => '{"result":"true","message":"Usuario cadastrado com sucesso."}' }
          else
            clean_up_passwords resource
            set_minimum_password_length
            format.html { render :new }
            format.json { render :json => '{"result":"false","message":"Preencha todos os campos."}' }
          end
        end
    end

  end

  def update
    super
  end
end
