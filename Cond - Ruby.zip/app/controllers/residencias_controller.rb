class ResidenciasController < ApplicationController
  before_filter :auth_admin
  before_action :set_residencia, only: [:show, :edit, :update, :destroy]

  # GET /residencias
  # GET /residencias.json
  def index
    @residencias = Residencia.all


    where="id >0 "
    if params[:numero] != nil && params[:numero].length>0
      where+=" and numero like '%"+params[:numero]+"%' "
    end

    if params[:condominio_id] != nil && params[:condominio_id].length>0
      where+=" and condominio_id = "+params[:condominio_id].to_s
    end

    if params[:bloco_id] != nil && params[:bloco_id].length>0
      where+=" and bloco_id = "+params[:bloco_id].to_s
    end

    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end
    where+=" and administradora_id = " + current_user.administradora_id.to_s+" "
    @residencias = @residencias.paginate(:page => params[:page], :per_page => 10).order('numero ASC').where(where)
  end

  # GET /residencias/1
  # GET /residencias/1.json
  def show
  end

  # GET /residencias/new
  def new
    @residencia = Residencia.new
  end

  # GET /residencias/1/edit
  def edit
  end

  # POST /residencias
  # POST /residencias.json
  def create
    @residencia = Residencia.new(residencia_params)

    respond_to do |format|
      if @residencia.save
        format.html { redirect_to residencias_path, notice: 'Residencia criada com sucesso.' }
        format.json { render :show, status: :created, location: @residencia }
      else
        format.html { render :new }
        format.json { render json: @residencia.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /residencias/1
  # PATCH/PUT /residencias/1.json
  def update
    respond_to do |format|
      if @residencia.update(residencia_params)
        format.html { redirect_to residencias_path, notice: 'Residencia editada com sucesso.' }
        format.json { render :show, status: :ok, location: @residencia }
      else
        format.html { render :edit }
        format.json { render json: @residencia.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /residencias/1
  # DELETE /residencias/1.json
  def destroy
    if(@residencia.ativo=="N")
      @residencia.update({"ativo"=>"S"})
    else
      @residencia.update({"ativo"=>"N"})
    end

    respond_to do |format|
      if(@residencia.ativo=="N")
        format.html { redirect_to residencias_url, notice: 'Residencia desativada com sucesso.' }
      else
        format.html { redirect_to residencias_url, notice: 'Residencia ativada com sucesso.' }
      end

      format.json { head :no_content }
    end
  end
  def get_blocos
    @blocos = Bloco.where("ativo ='S' AND condominio_id="+params[:condominio_id].to_s)

  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_residencia
      @residencia = Residencia.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def residencia_params
      params.require(:residencia).permit(:numero, :administradora_id, :condominio_id, :bloco_id, :ativo, :cpf_titular)
    end
end
