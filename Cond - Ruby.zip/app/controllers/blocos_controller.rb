class BlocosController < ApplicationController
  before_filter :auth_admin
  before_action :set_bloco, only: [:show, :edit, :update, :destroy]

  # GET /blocos
  # GET /blocos.json
  def index
    @blocos = Bloco.all


    where="id >0 "
    if params[:nome] != nil && params[:nome].length>0
      where+=" and nome like '%"+params[:nome]+"%' "
    end

    if params[:condominio_id] != nil && params[:condominio_id].length>0
      where+=" and condominio_id = "+params[:condominio_id].to_s
    end

    if params[:ativo] != nil && params[:ativo].length>0
      where+=" and ativo = '"+params[:ativo]+"' "
    end
    where+=" and administradora_id = " + current_user.administradora_id.to_s+" "
    @blocos = @blocos.paginate(:page => params[:page], :per_page => 10).order('nome ASC').where(where)
  end

  # GET /blocos/1
  # GET /blocos/1.json
  def show
  end

  # GET /blocos/new
  def new
    @bloco = Bloco.new
  end

  # GET /blocos/1/edit
  def edit
  end

  # POST /blocos
  # POST /blocos.json
  def create
    @bloco = Bloco.new(bloco_params)

    respond_to do |format|
      if @bloco.save
        format.html { redirect_to blocos_path, notice: 'Bloco criado com sucesso.' }
        format.json { render :show, status: :created, location: @bloco }
      else
        format.html { render :new }
        format.json { render json: @bloco.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /blocos/1
  # PATCH/PUT /blocos/1.json
  def update
    respond_to do |format|
      if @bloco.update(bloco_params)
        format.html { redirect_to blocos_path, notice: 'Bloco editado com sucesso.' }
        format.json { render :show, status: :ok, location: @bloco }
      else
        format.html { render :edit }
        format.json { render json: @bloco.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /blocos/1
  # DELETE /blocos/1.json
  def destroy
    if(@bloco.ativo=="N")
      @bloco.update({"ativo"=>"S"})
    else
      @bloco.update({"ativo"=>"N"})
    end

    respond_to do |format|
      if(@bloco.ativo=="N")
        format.html { redirect_to blocos_url, notice: 'Bloco desativado com sucesso.' }
      else
        format.html { redirect_to blocos_url, notice: 'Bloco ativado com sucesso.' }
      end

      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_bloco
      @bloco = Bloco.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def bloco_params
      params.require(:bloco).permit(:nome, :condominio_id, :ativo, :administradora_id)
    end
end
