class Bloco < ActiveRecord::Base
  belongs_to :administradora
  belongs_to :condominio
  has_many :residencias
end
