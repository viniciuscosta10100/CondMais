class Estado < ActiveRecord::Base
end
