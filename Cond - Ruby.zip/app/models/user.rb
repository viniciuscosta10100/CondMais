class User < ActiveRecord::Base
  #TIPOS
  #R-ROOT
  #A-ADMINISTRADORA
  #M-MORADOR
  #S-SINDICO
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable

  belongs_to :administradora
  belongs_to :condominio
  belongs_to :residencia
  has_many :agendamentos
  has_many :mensagens
  has_many :reinvidicacoes
  has_many :comentario_reinvidicacoes
  has_many :membros
end
