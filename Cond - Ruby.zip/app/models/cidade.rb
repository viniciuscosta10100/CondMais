class Cidade < ActiveRecord::Base
end
