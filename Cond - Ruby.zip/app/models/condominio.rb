class Condominio < ActiveRecord::Base
  mount_uploader :foto, LogoUploader
  has_many :users
  has_many :blocos
  has_many :avisos
  has_many :enquetes
  has_many :ambientes
  has_many :residencias
  has_many :reinvidicacoes
  belongs_to :administradora
  belongs_to :cidade
  belongs_to :estado

end
