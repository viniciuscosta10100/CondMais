class Administradora < ActiveRecord::Base
  mount_uploader :logo, LogoUploader
  has_many :users
  has_many :blocos
  has_many :ambientes
  has_many :condominios
  has_many :residencias
  has_many :reinvidicacoes
end
