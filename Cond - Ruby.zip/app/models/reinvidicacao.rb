class Reinvidicacao < ActiveRecord::Base
  belongs_to :user
  belongs_to :condominio
  belongs_to :administradora
  has_many :comentario_reinvidicacoes

end
