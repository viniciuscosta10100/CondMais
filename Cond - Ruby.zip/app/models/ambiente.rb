class Ambiente < ActiveRecord::Base
  belongs_to :administradora
  belongs_to :condominio
  has_many :agendamentos
end
