class Agendamento < ActiveRecord::Base
  belongs_to :user
  belongs_to :ambiente
end
