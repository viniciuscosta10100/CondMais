class Residencia < ActiveRecord::Base
  belongs_to :administradora
  belongs_to :condominio
  belongs_to :bloco
  has_many :users
end
