class ComentarioReinvidicacao < ActiveRecord::Base
  belongs_to :reinvidicacao
  belongs_to :user

end
