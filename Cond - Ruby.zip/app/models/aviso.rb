class Aviso < ActiveRecord::Base
  belongs_to :condominio
end
